function EmailComponent() {
    return (
        <div>
            <h2>Email Component</h2>
        </div>
    );
}

export default EmailComponent;