import HeaderComponent from './header';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";


function App() {
  return (
    <div>
      <HeaderComponent /> 
    </div>
  );
}

export default App;
